﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameOver_Control : MonoBehaviour
{
    
    public void GameOver()
    {
        
    }
}
